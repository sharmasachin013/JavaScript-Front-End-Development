<?php



namespace Drupal\news\Plugin\rest\resource;

use Drupal\Core\KeyValueStore\KeyValueFactoryInterface;
use Drupal\Core\KeyValueStore\KeyValueStoreInterface;
use Drupal\rest\ModifiedResourceResponse;
use Drupal\rest\Plugin\ResourceBase;
use Drupal\rest\ResourceResponse;
use Psr\Log\LoggerInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;
use Symfony\Component\Routing\Route;
use Drupal\file\Entity\File;
use Drupal\taxonomy\Entity\Term;
use Drupal\node\Entity\Node;

/**
 * Represents News records as resources.
 *
 * @RestResource (
 *   id = "news_news",
 *   label = @Translation("News"),
 *   uri_paths = {
 *     "canonical" = "/api/decoupled-news/{path}",
 *     "create" = "/api/decoupled-news"
 *   }
 * )
 *
 * @DCG
 * The plugin exposes key-value records as REST resources. In order to enable it
 * import the resource configuration into active configuration storage. An
 * example of such configuration can be located in the following file:
 * core/modules/rest/config/optional/rest.resource.entity.node.yml.
 * Alternatively, you can enable it through admin interface provider by REST UI
 * module.
 * @see https://www.drupal.org/project/restui
 *
 * @DCG
 * Notice that this plugin does not provide any validation for the data.
 * Consider creating custom normalizer to validate and normalize the incoming
 * data. It can be enabled in the plugin definition as follows.
 * @code
 *   serialization_class = "Drupal\foo\MyDataStructure",
 * @endcode
 *
 * @DCG
 * For entities, it is recommended to use REST resource plugin provided by
 * Drupal core.
 * @see \Drupal\rest\Plugin\rest\resource\EntityResource
 */
final class NewsResource extends ResourceBase {

  /**
   * The key-value storage.
   */
  private readonly KeyValueStoreInterface $storage;

  /**
   * {@inheritdoc}
   */
  public function __construct(
    array $configuration,
    $plugin_id,
    $plugin_definition,
    array $serializer_formats,
    LoggerInterface $logger,
    KeyValueFactoryInterface $keyValueFactory,
  ) {
    parent::__construct($configuration, $plugin_id, $plugin_definition, $serializer_formats, $logger);
    $this->storage = $keyValueFactory->get('news_news');
  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container, array $configuration, $plugin_id, $plugin_definition): self {
    return new self(
      $configuration,
      $plugin_id,
      $plugin_definition,
      $container->getParameter('serializer.formats'),
      $container->get('logger.factory')->get('rest'),
      $container->get('keyvalue')
    );
  }

  /**
   * Responds to POST requests and saves the new record.
   */
  public function post(array $data): ModifiedResourceResponse {
    $data['id'] = $this->getNextId();
    $this->storage->set($data['id'], $data);
    $this->logger->notice('Created new news record @id.', ['@id' => $data['id']]);
    // Return the newly created record in the response body.
    return new ModifiedResourceResponse($data, 201);
  }

  /**
   * Responds to GET requests.
   */
  public function get($path): ResourceResponse {

    $newsResponse = [];
    $sliderRightCount = 0;
    $newsData["latestNews"][] = $this->latestNews();

    $currentPath = \Drupal::service("path.current")->getPath();
    $pathItems = explode("/",$currentPath);
    $requestNameAlias = $pathItems[3];
    $host = \Drupal::request()->getschemeAndHttpHost();
    
   try{
    if(empty($requestNameAlias)){
       $statusCode = 404;
       $statusMessage = "Bad Request";
       throw new \Exception("Name query missing!");

    } else {

      $nodeId = $this->getNode($requestNameAlias);

      $node = \Drupal::entityTypeManager()
              ->getStorage("node")
              ->load($nodeId);


      $fieldNews = $node->field_news->getValue();
      foreach($fieldNews as $newsItem){
          $news = \Drupal::entityTypeManager()
              ->getStorage("node")
              ->load($newsItem['target_id']);

             // $slider = $this->getSlider($news);
             $sliderDataOne = $this->getSlider($news);
             if (sizeof($sliderDataOne) > 0) {
                        $newsData["maincarousel"][] = $sliderDataOne;
              }
              $sliderDataTwo = $this->getSliderTwo($news);
              if (sizeof($sliderDataTwo) > 0) {
                        if($sliderRightCount <= 3)
                        $newsData["silderRight"][] = $sliderDataTwo;
                        $sliderRightCount++;
                    }

      }

      $featuredId = $this->getTermId("featured");
      $trandingId = $this->getTermId("tranding");




      if($featuredId)  {
         $featuredData = $this->getFeaturedNode(
                            $news,
                            $featuredId
                        );
                        if ($featuredData) {
                            $newsData["featuredNode"][] = $featuredData;
                        }

      }

      if($trandingId) {
        $trandingData = $this->getTrandingNews($trandingId);
        

      }

      if($trandingData) {
        $newsData["trandingNode"][] = $trandingData;

      }


              
      if(empty($nodeId)){
        $response = [
                    "statusCode" => 404,
                    "statusMessage" => "Not Found",
                    "supportMessage" => "Content Not Found.",
                ];
   
    return new ResourceResponse($response);

      }


      
       
    
      


    }
  }catch(\Exception $e){

    }

    $response = [
                    "statusCode" => 200,
                    "statusMessage" => "Success",
                    "supportMessage" => "Processed successfully.",
                    "data" => $newsData,
                ];
   
    return new ResourceResponse($response);
  }

  private function getNode($path)
  {
    $result = \Drupal::database()
              ->select("path_alias","p")
              ->fields("p")
              ->condition("alias","/".$path) // /home
              ->execute()
              ->fetchObject();
     
     return  $result && $result->path ? str_replace("/node/","",$result->path) : "";        




  }

  private function getSlider($node){
    $data = [];
    $sliderImg = $node->field_banner_3->getValue();
    if(sizeof($sliderImg)> 0){
      $data["title"] = $node->getTitle();
      $file = File::load($sliderImg[0]["target_id"]);
      $uri = $file->getFileUri();
      $url_generator = \Drupal::service("file_url_generator");
      $url = $url_generator->generateAbsoluteString($uri);
      $data["largeImg"] = $url;
      $fieldNewsCategories = $node->field_categories->getValue();
      if(sizeof($fieldNewsCategories) > 0){
        $term = Term::load($fieldNewsCategories[0]["target_id"]);
        if($term)
        {
          $data["category"] = $term->getName();

        }
      }
    }
   return $data;


  }


  private function getSliderTwo($node)
  {
     $data = [];
     $sliderImg = $node->field_banner_2->getValue();
     if (sizeof($sliderImg) > 0) { 
       $data["title"] = $node->getTitle();
       $file = File::load($sliderImg[0]["target_id"]);
       $uri = $file->getFileUri();
       $url_generator = \Drupal::service("file_url_generator");
       $url = $url_generator->generateAbsoluteString($uri);
       $data["imgUrl"] = $url;
       $fieldNewsCategories = $node->field_categories->getValue();
       if (sizeof($fieldNewsCategories) > 0) {
                $term = Term::load($fieldNewsCategories[0]["target_id"]);
                if ($term) {
                    $data["category"] = $term->getName();
                }
            }


     }
     return $data;

  }

  /**
   * Responds to PATCH requests.
   */
  public function patch($id, array $data): ModifiedResourceResponse {
    if (!$this->storage->has($id)) {
      throw new NotFoundHttpException();
    }
    $stored_data = $this->storage->get($id);
    $data += $stored_data;
    $this->storage->set($id, $data);
    $this->logger->notice('The news record @id has been updated.', ['@id' => $id]);
    return new ModifiedResourceResponse($data, 200);
  }

  /**
   * Responds to DELETE requests.
   */
  public function delete($id): ModifiedResourceResponse {
    if (!$this->storage->has($id)) {
      throw new NotFoundHttpException();
    }
    $this->storage->delete($id);
    $this->logger->notice('The news record @id has been deleted.', ['@id' => $id]);
    // Deleted responses have an empty body.
    return new ModifiedResourceResponse(NULL, 204);
  }

  /**
   * {@inheritdoc}
   */
  protected function getBaseRoute($canonical_path, $method): Route {
    $route = parent::getBaseRoute($canonical_path, $method);
    // Set ID validation pattern.
    if ($method !== 'POST') {
      $route->setRequirement('id', '\d+');
    }
    return $route;
  }

  /**
   * Returns next available ID.
   */
  private function getNextId(): int {
    $ids = array_keys($this->storage->getAll());
    return count($ids) > 0 ? max($ids) + 1 : 1;
  }

  private function getTermId($name)
  {
    $terms = \Drupal::entityTypeManager()
         ->getStorage("taxonomy_term")
         ->loadByProperties([
                "name" => $name,
                "vid" => "type",
            ]);
    
             $term = reset($terms);
            return $term->id();

  }

   private function getFeaturedNode($node, $id)
    { 
      $data = [];
       $sliderImg = $node->field_banner_2->getValue();
       $fieldType = $node->field_type->getValue(); 
       foreach ($fieldType as $val) { 
          if ($id === $val["target_id"]) {
             if (sizeof($fieldType) > 0) { 
               $data["title"] = $node->getTitle();
               $file = File::load($sliderImg[0]["target_id"]);
               $uri = $file->getFileUri();
               $url_generator = \Drupal::service("file_url_generator");
               $url = $url_generator->generateAbsoluteString($uri);
               $data["imgUrl"] = $url;
               $fieldNewsCategories = $node->field_categories->getValue();
               if (sizeof($fieldNewsCategories) > 0) {
                 $term = Term::load($fieldNewsCategories[0]["target_id"]);
                if ($term) {
                    $data["category"] = $term->getName();
                }
               }
             } 
          }
       }

       return $data;
       
    }

    private function getTrandingNews($termId) 
    {
      $query = \Drupal::entityQuery("node")
          ->condition("status", 1) // Only published nodes.
          ->condition("type", "news")
          ->condition('field_type', $termId)  
          ->sort("created", "DESC") // Sort by creation date, descending.
          ->range(0, 8) // Limit to the first 5 results.
          ->accessCheck(true);

      $nids = $query->execute();
      $nodes = Node::loadMultiple($nids);
      $nodes_array = [];
      foreach ($nodes as $node) 
      { 
        $sliderImg = $node->field_banner_1->getValue();
        if (sizeof($sliderImg) > 0) {
                $file = File::load($sliderImg[0]["target_id"]);
                $uri = $file->getFileUri();
                $url_generator = \Drupal::service("file_url_generator");
                $url = $url_generator->generateAbsoluteString($uri);
            }
            
          $fieldNewsCategories = $node->field_categories->getValue();
                    if (sizeof($fieldNewsCategories) > 0) {
                        $term = Term::load(
                            $fieldNewsCategories[0]["target_id"]
                        );
                   
                    } 
                    
          $nodes_array[] = [
           'nid' => $node->id(),
           'title' => $node->getTitle(),
           'body' => $node->get('body')->value,
           'created' => $node->getCreatedTime(),
            'imgUrl' => $url,
           'category' => $term->getName(),
    // Add more fields as needed
  ];          

      }


    return $nodes_array;

    }

    private function latestNews() {
          $query = \Drupal::entityQuery("node")
            ->condition("status", 1) // Only published nodes.
            ->condition("type", "news")
            ->sort("created", "DESC") // Sort by creation date, descending.
            ->range(0, 8) // Limit to the first 5 results.
            ->accessCheck(true);
            
      $nids = $query->execute();
      $nodes = Node::loadMultiple($nids);


       // Prepare the response data.
        $data = [];
        foreach ($nodes as $node) {
            $sliderImg =  $node->field_banner_3->getValue();
            if (sizeof($sliderImg) > 0) {
                $file = File::load($sliderImg[0]["target_id"]);
                $uri = $file->getFileUri();
                $url_generator = \Drupal::service("file_url_generator");
                $url = $url_generator->generateAbsoluteString($uri);
            }

            $fieldNewsCategories = $node->field_categories->getValue();
            if (sizeof($fieldNewsCategories) > 0) {
                $term = Term::load($fieldNewsCategories[0]["target_id"]);
                if ($term) {
                    $category = $term->getName();
                }
            }

            $data[] = [
                "nid" => $node->id(),
                "title" => $node->getTitle(),
                "created" => $node->getCreatedTime(),
                "type" => $node->getType(),
                "url" => $node->toUrl()->toString(),
                "imgUrl" => $url,
                "category" => $category,
            ];
        }


return $data;
    }
}
